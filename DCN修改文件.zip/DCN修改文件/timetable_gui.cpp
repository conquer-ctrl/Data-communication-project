#include "database.h"

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#include <windows.h>
#include <commctrl.h>
#include <string>
#include <vector>
#include <sstream>
#include <deque>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

namespace {
    const int MAX_LOG_LINES = 50;
    std::deque<std::wstring> g_logLines;

    constexpr int kPad = 12;
    constexpr int kLine = 28;

    enum {
        IDC_OUTPUT = 2000,
        IDC_BTN_CLEAR,
        IDC_LBL_CODE, IDC_ED_CODE, IDC_BTN_QCODE,
        IDC_LBL_INST, IDC_ED_INST, IDC_BTN_QINST,
        IDC_LBL_SEM, IDC_ED_SEM, IDC_BTN_QALL,
        IDC_LBL_USER, IDC_ED_USER, IDC_LBL_PASS, IDC_ED_PASS,
        IDC_BTN_LOGIN, IDC_BTN_LOGOUT,
        IDC_LBL_ADD, IDC_ED_ADD, IDC_BTN_ADD,
        IDC_LBL_UP, IDC_ED_UPCODE, IDC_ED_UPSEC, IDC_ED_FIELD, IDC_ED_UPVAL, IDC_BTN_UPDATE,
        IDC_LBL_DEL, IDC_ED_DELCODE, IDC_ED_DELSEC, IDC_BTN_DELETE,
        IDC_LBL_RAW, IDC_ED_RAW, IDC_BTN_SENDRAW,
        IDC_STATUS
    };

    HWND g_hwndMain = nullptr;
    HWND g_hwndOutput = nullptr;
    HWND g_hwndStatus = nullptr;
    HWND g_hwndClear = nullptr;
    int g_logTop = 0;
    ClientSession g_session;

    std::string wideToUtf8(const std::wstring& w) {
        if (w.empty()) return {};
        int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
        if (n <= 0) return {};
        std::string s((size_t)n, '\0');
        WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), &s[0], n, nullptr, nullptr);
        return s;
    }

    std::wstring utf8ToWide(const std::string& u8) {
        if (u8.empty()) return L"";
        int n = MultiByteToWideChar(CP_UTF8, 0, u8.c_str(), (int)u8.size(), nullptr, 0);
        if (n <= 0) return L"";
        std::wstring w((size_t)n, L'\0');
        MultiByteToWideChar(CP_UTF8, 0, u8.c_str(), (int)u8.size(), &w[0], n);
        return w;
    }

    std::wstring getEditText(HWND h) {
        int len = GetWindowTextLengthW(h);
        if (len <= 0) return L"";
        std::wstring s(len + 1, L'\0');
        GetWindowTextW(h, &s[0], len + 1);
        s.resize(len);
        return s;
    }

    void refreshLog() {
        SetWindowTextW(g_hwndOutput, L"");
        std::wstring buf;
        for (auto& line : g_logLines) {
            buf += line + L"\r\n";
        }
        int len = GetWindowTextLengthW(g_hwndOutput);
        SendMessageW(g_hwndOutput, EM_SETSEL, len, len);
        SendMessageW(g_hwndOutput, EM_REPLACESEL, 0, (LPARAM)buf.c_str());
        SendMessageW(g_hwndOutput, EM_SCROLLCARET, 0, 0);
    }

    void addLogLine(const std::wstring& line) {
        if (g_logLines.size() >= MAX_LOG_LINES) {
            g_logLines.pop_front();
        }
        g_logLines.push_back(line);
        refreshLog();
    }

    void appendOutputUtf8(const std::string& s) {
        std::wstring w = utf8ToWide(s);
        addLogLine(w);
    }

    void clearLog() {
        g_logLines.clear();
        refreshLog();
    }

    std::string formatReply(const std::string& reply) {
        std::string out;
        std::stringstream ss(reply);
        std::string line;
        int cnt = 0;
        const int SHOW_MAX = 30;

        while (getline(ss, line)) {
            if (!line.empty()) {
                if (cnt < SHOW_MAX) {
                    out += line + "\r\n";
                }
                cnt++;
            }
        }
        if (cnt > SHOW_MAX) {
            out += "... skipped " + std::to_string(cnt - SHOW_MAX) + " lines ...\r\n";
        }
        return out;
    }

    void updateAdminUI() {
        HWND btnLogin = GetDlgItem(g_hwndMain, IDC_BTN_LOGIN);
        HWND btnLogout = GetDlgItem(g_hwndMain, IDC_BTN_LOGOUT);
        EnableWindow(GetDlgItem(g_hwndMain, IDC_ED_ADD), g_session.isAdmin);
        EnableWindow(GetDlgItem(g_hwndMain, IDC_BTN_ADD), g_session.isAdmin);
        EnableWindow(GetDlgItem(g_hwndMain, IDC_BTN_UPDATE), g_session.isAdmin);
        EnableWindow(GetDlgItem(g_hwndMain, IDC_BTN_DELETE), g_session.isAdmin);
        ShowWindow(btnLogin, g_session.isAdmin ? SW_HIDE : SW_SHOW);
        ShowWindow(btnLogout, g_session.isAdmin ? SW_SHOW : SW_HIDE);
    }

    void updateStatus() {
        std::wstring s = g_session.isAdmin ? L"Admin: " + utf8ToWide(g_session.username) : L"Guest";
        SetWindowTextW(g_hwndStatus, s.c_str());
        updateAdminUI();
    }

    void runLine(const std::string& line) {
        std::string reply = handleRequest(line, g_session);
        appendOutputUtf8("> " + line);
        appendOutputUtf8(formatReply(reply));
        appendOutputUtf8("");
        updateStatus();
    }

    void stripExeName(wchar_t* path) {
        wchar_t* p = wcsrchr(path, L'\\');
        if (p) *p = 0;
    }

    void initDataDirectoryNearExe() {
        wchar_t buf[MAX_PATH];
        GetModuleFileNameW(NULL, buf, MAX_PATH);
        stripExeName(buf);
        setDatabaseDataDirectory(wideToUtf8(buf));
    }

    void resizeAllControls(int cx, int cy) {
        int y = kPad;
        int fw = cx - 2 * kPad;
        int bw = 150;

        HDWP h = BeginDeferWindowPos(40);
        g_hwndStatus = GetDlgItem(g_hwndMain, IDC_STATUS);
        DeferWindowPos(h, g_hwndStatus, 0, kPad, y, fw, 24, 0); y += 30;

        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_LBL_CODE), 0, kPad, y, 140, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_CODE), 0, kPad + 145, y, fw - 145 - bw - 8, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_BTN_QCODE), 0, fw - bw + 8, y, bw, 24, SWP_NOZORDER); y += 28;

        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_LBL_INST), 0, kPad, y, 140, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_INST), 0, kPad + 145, y, fw - 145 - bw - 8, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_BTN_QINST), 0, fw - bw + 8, y, bw, 24, SWP_NOZORDER); y += 28;

        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_LBL_SEM), 0, kPad, y, 140, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_SEM), 0, kPad + 145, y, fw - 145 - bw - 8, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_BTN_QALL), 0, fw - bw + 8, y, bw, 24, SWP_NOZORDER); y += 36;

        DeferWindowPos(h, GetDlgItem(g_hwndMain, 2098), 0, kPad, y, fw, 24, SWP_NOZORDER); y += 30;
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_LBL_USER), 0, kPad, y, 40, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_USER), 0, kPad + 45, y, 120, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_LBL_PASS), 0, kPad + 170, y, 40, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_PASS), 0, kPad + 215, y, 120, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_BTN_LOGIN), 0, kPad + 345, y, 80, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_BTN_LOGOUT), 0, kPad + 345, y, 80, 24, SWP_NOZORDER); y += 32;

        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_LBL_ADD), 0, kPad, y, fw, 24, SWP_NOZORDER); y += 26;
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_ADD), 0, kPad, y, fw - bw - 8, 60, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_BTN_ADD), 0, fw - bw + 8, y, bw, 60, SWP_NOZORDER); y += 68;

        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_LBL_UP), 0, kPad, y, fw, 24, SWP_NOZORDER); y += 26;
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_UPCODE), 0, kPad, y, 100, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_UPSEC), 0, kPad + 105, y, 80, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_FIELD), 0, kPad + 190, y, 120, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_UPVAL), 0, kPad + 315, y, 140, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_BTN_UPDATE), 0, fw - bw + 8, y, bw, 24, SWP_NOZORDER); y += 28;

        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_LBL_DEL), 0, kPad, y, fw, 24, SWP_NOZORDER); y += 26;
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_DELCODE), 0, kPad, y, 140, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_DELSEC), 0, kPad + 145, y, 140, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_BTN_DELETE), 0, fw - bw + 8, y, bw, 24, SWP_NOZORDER); y += 28;

        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_LBL_RAW), 0, kPad, y, fw, 24, SWP_NOZORDER); y += 26;
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_ED_RAW), 0, kPad, y, fw - bw - 8, 24, SWP_NOZORDER);
        DeferWindowPos(h, GetDlgItem(g_hwndMain, IDC_BTN_SENDRAW), 0, fw - bw + 8, y, bw, 24, SWP_NOZORDER); y += 28;

        g_logTop = y;
        int logH = cy - y - 36;
        if (logH < 80) logH = 80;
        DeferWindowPos(h, g_hwndOutput, 0, kPad, y, fw, logH, SWP_NOZORDER);
        DeferWindowPos(h, g_hwndClear, 0, kPad, cy - 28, 100, 24, SWP_NOZORDER);
        EndDeferWindowPos(h);
    }

    void createControls(HWND hwnd) {
        g_hwndMain = hwnd;

        CreateWindowExW(0, L"STATIC", L"", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_STATUS, NULL, NULL);
        CreateWindowExW(0, L"STATIC", L"Course code", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_LBL_CODE, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_CODE, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"Query by code", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_QCODE, NULL, NULL);

        CreateWindowExW(0, L"STATIC", L"Instructor", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_LBL_INST, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_INST, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"Query by name", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_QINST, NULL, NULL);

        CreateWindowExW(0, L"STATIC", L"Semester", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_LBL_SEM, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_SEM, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"List all", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_QALL, NULL, NULL);

        CreateWindowExW(0, L"STATIC", L"--- Administrator ---", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)2098, NULL, NULL);
        CreateWindowExW(0, L"STATIC", L"User", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_LBL_USER, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_USER, NULL, NULL);
        CreateWindowExW(0, L"STATIC", L"Pass", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_LBL_PASS, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_PASSWORD, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_PASS, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"Login", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_LOGIN, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"Logout", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_LOGOUT, NULL, NULL);

        CreateWindowExW(0, L"STATIC", L"Add course (CSV)", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_LBL_ADD, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_ADD, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"Add", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_ADD, NULL, NULL);

        CreateWindowExW(0, L"STATIC", L"Update: code / sec / field / value", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_LBL_UP, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_UPCODE, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_UPSEC, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_FIELD, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_UPVAL, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"Update", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_UPDATE, NULL, NULL);

        CreateWindowExW(0, L"STATIC", L"Delete: code / sec", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_LBL_DEL, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_DELCODE, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_DELSEC, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"Delete", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_DELETE, NULL, NULL);

        CreateWindowExW(0, L"STATIC", L"Raw command", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_LBL_RAW, NULL, NULL);
        CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_ED_RAW, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"Send", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_SENDRAW, NULL, NULL);

        g_hwndOutput = CreateWindowExW(
            WS_EX_CLIENTEDGE,
            L"EDIT",
            L"",
            WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_WANTRETURN | ES_AUTOVSCROLL | WS_VSCROLL | ES_READONLY,
            0, 0, 0, 0,
            hwnd,
            (HMENU)(LONG_PTR)IDC_OUTPUT,
            NULL, NULL
        );

        g_hwndClear = CreateWindowExW(0, L"BUTTON", L"Clear log", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)(LONG_PTR)IDC_BTN_CLEAR, NULL, NULL);

        SetWindowTextW(GetDlgItem(hwnd, IDC_ED_USER), L"admin");
        SetWindowTextW(GetDlgItem(hwnd, IDC_ED_PASS), L"123456");
        clearLog();
        updateStatus();
    }

    LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
        switch (msg) {
        case WM_CREATE: {
            createControls(hwnd);
            RECT r; GetClientRect(hwnd, &r);
            resizeAllControls(r.right, r.bottom);
            addLogLine(L"Ready");
            return 0;
        }
        case WM_SIZE:
            resizeAllControls(LOWORD(lp), HIWORD(lp));
            return 0;
        case WM_COMMAND: {
            int id = LOWORD(wp);
            if (id == IDC_BTN_CLEAR) { clearLog(); return 0; }
            if (id == IDC_BTN_QCODE) {
                std::wstring w = getEditText(GetDlgItem(hwnd, IDC_ED_CODE));
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_CODE), L"");
                runLine("QUERY CODE " + wideToUtf8(w));
                return 0;
            }
            if (id == IDC_BTN_QINST) {
                std::wstring w = getEditText(GetDlgItem(hwnd, IDC_ED_INST));
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_INST), L"");
                runLine("QUERY INSTRUCTOR " + wideToUtf8(w));
                return 0;
            }
            if (id == IDC_BTN_QALL) {
                std::wstring w = getEditText(GetDlgItem(hwnd, IDC_ED_SEM));
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_SEM), L"");
                if (w.empty()) runLine("QUERY ALL");
                else runLine("QUERY ALL " + wideToUtf8(w));
                return 0;
            }
            if (id == IDC_BTN_LOGIN) {
                std::wstring u = getEditText(GetDlgItem(hwnd, IDC_ED_USER));
                std::wstring p = getEditText(GetDlgItem(hwnd, IDC_ED_PASS));
                runLine("LOGIN " + wideToUtf8(u) + " " + wideToUtf8(p));
                return 0;
            }
            if (id == IDC_BTN_LOGOUT) { runLine("LOGOUT"); return 0; }
            if (id == IDC_BTN_ADD) {
                std::wstring w = getEditText(GetDlgItem(hwnd, IDC_ED_ADD));
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_ADD), L"");
                runLine("ADD COURSE " + wideToUtf8(w));
                return 0;
            }

            // ====================== 完全对齐控制台客户端 ======================
            if (id == IDC_BTN_UPDATE) {
                std::wstring c = getEditText(GetDlgItem(hwnd, IDC_ED_UPCODE));
                std::wstring sec = getEditText(GetDlgItem(hwnd, IDC_ED_UPSEC));
                std::wstring f = getEditText(GetDlgItem(hwnd, IDC_ED_FIELD));
                std::wstring v = getEditText(GetDlgItem(hwnd, IDC_ED_UPVAL));

                std::string cmd;
                if (!sec.empty()) {
                    cmd = "UPDATE " + wideToUtf8(c) + " SECTION " + wideToUtf8(sec) + " " + wideToUtf8(f) + " " + wideToUtf8(v);
                }
                else {
                    cmd = "UPDATE " + wideToUtf8(c) + " " + wideToUtf8(f) + " " + wideToUtf8(v);
                }

                runLine(cmd);
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_UPCODE), L"");
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_UPSEC), L"");
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_FIELD), L"");
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_UPVAL), L"");
                return 0;
            }

            if (id == IDC_BTN_DELETE) {
                std::wstring c = getEditText(GetDlgItem(hwnd, IDC_ED_DELCODE));
                std::wstring sec = getEditText(GetDlgItem(hwnd, IDC_ED_DELSEC));

                std::string cmd;
                if (!sec.empty()) {
                    cmd = "DELETE " + wideToUtf8(c) + " SECTION " + wideToUtf8(sec);
                }
                else {
                    cmd = "DELETE " + wideToUtf8(c);
                }

                runLine(cmd);
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_DELCODE), L"");
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_DELSEC), L"");
                return 0;
            }

            if (id == IDC_BTN_SENDRAW) {
                std::wstring w = getEditText(GetDlgItem(hwnd, IDC_ED_RAW));
                SetWindowTextW(GetDlgItem(hwnd, IDC_ED_RAW), L"");
                runLine(wideToUtf8(w));
                return 0;
            }
            return 0;
        }
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        default:
            return DefWindowProcW(hwnd, msg, wp, lp);
        }
    }
}

int WINAPI wWinMain(HINSTANCE hi, HINSTANCE, PWSTR, int nShow) {
    INITCOMMONCONTROLSEX ic{ sizeof(ic), ICC_STANDARD_CLASSES };
    InitCommonControlsEx(&ic);
    initDataDirectoryNearExe();

    WNDCLASSW wc{};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hi;
    wc.lpszClassName = L"GUI";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    RegisterClassW(&wc);

    HWND hwnd = CreateWindowExW(0, L"GUI", L"Course System", WS_OVERLAPPEDWINDOW, 100, 100, 920, 720, NULL, NULL, hi, NULL);
    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG m;
    while (GetMessageW(&m, NULL, 0, 0)) { TranslateMessage(&m); DispatchMessage(&m); }
    return (int)m.wParam;
}