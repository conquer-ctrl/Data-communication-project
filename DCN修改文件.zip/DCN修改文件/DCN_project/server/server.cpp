#include <iostream>
#include <string>
#include <thread>
#include <vector>
#include <winsock2.h>
#include <ws2tcpip.h>
#include "database.h" 

#pragma comment(lib, "ws2_32.lib")

using namespace std;

const int PORT = 8888;

void handleClient(SOCKET clientSocket) {
    ClientSession session; 
    char buffer[4096];
    string accumulatedData = "";

    cout << "[Server] New client connected. Thread ID: " << this_thread::get_id() << endl;

    while (true) {
        int bytesReceived = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
        if (bytesReceived <= 0) {
            cout << "[Server] Client disconnected." << endl;
            break;
        }
        
        buffer[bytesReceived] = '\0';
        accumulatedData += buffer;

        size_t pos;
        while ((pos = accumulatedData.find('\n')) != string::npos) {
            string request = accumulatedData.substr(0, pos);
            accumulatedData.erase(0, pos + 1);

            if (!request.empty() && request.back() == '\r') {
                request.pop_back();
            }

            if (request.empty()) continue;

            cout << "[Server] Received request: " << request << endl;

            string response = handleRequest(request, session);

            string finalResponse = response + "\n__EOF__\n";

            send(clientSocket, finalResponse.c_str(), finalResponse.length(), 0);
        }
    }
    closesocket(clientSocket);
}

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "WSAStartup failed." << endl;
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        cerr << "Socket creation failed." << endl;
        WSACleanup();
        return 1;
    }

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    if (bind(serverSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        cerr << "Bind failed." << endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    if (listen(serverSocket, SOMAXCONN) == SOCKET_ERROR) {
        cerr << "Listen failed." << endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    cout << "=== Timetable Server Started on Port " << PORT << " ===" << endl;
    cout << "Waiting for clients to connect..." << endl;

    while (true) {
        SOCKET clientSocket = accept(serverSocket, nullptr, nullptr);
        if (clientSocket == INVALID_SOCKET) {
            cerr << "Accept failed." << endl;
            continue;
        }
        thread clientThread(handleClient, clientSocket);
        clientThread.detach(); 
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}